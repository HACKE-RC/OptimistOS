#ifdef __SSE2__
#define L_divhc3
#include "libgcc2.c"
#endif
