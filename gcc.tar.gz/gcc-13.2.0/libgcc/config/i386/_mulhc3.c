#ifdef __SSE2__
#define L_mulhc3
#include "libgcc2.c"
#endif
